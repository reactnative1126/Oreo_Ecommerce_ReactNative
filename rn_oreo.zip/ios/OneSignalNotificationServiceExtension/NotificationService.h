//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Dang Tien Ngoc on 11/21/19.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end

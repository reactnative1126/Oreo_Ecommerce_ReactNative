import SearchBar from '../SearchBar-default';
import { commonTests } from './common';

describe('Default SearchBar component', () => {
  commonTests(SearchBar);
});

export const API = 'https://wc.rnlab.io';

export const CONSUMER_KEY = 'ck_9a40d82e47c124bc1be422682dd93eb25bdb5e3a';
export const CONSUMER_SECRET = 'cs_01bd2047d4ea33bdb4b6d8f6f034e0e072abdf4a';

export default {
  API_ENDPOINT: API,
  CONSUMER_KEY,
  CONSUMER_SECRET
};

export default {
  AppleAppID: '1475075333',
  GooglePackageName: 'com.rn_oreo',
  preferInApp: true,
  openAppStoreIfInAppFails: true,
};

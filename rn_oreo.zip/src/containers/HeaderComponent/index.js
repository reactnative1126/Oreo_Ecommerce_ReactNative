import IconHeader from './Icon';
import CartIcon from './CartIcon';
import Logo from './Logo';
import TextHeader from './TextHeader';

export { IconHeader, CartIcon, Logo, TextHeader };

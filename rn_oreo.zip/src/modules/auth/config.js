export const shippingAddressInit = {
  first_name: '',
  last_name: '',
  address_1: '',
  address_2: '',
  city: '',
  state: '',
  company: '',
  postcode: '',
  country: '',
  email: '',
  phone: '',
};

export const errorInit = {
  type: 'error',
  message: '',
  errors: {},
};
